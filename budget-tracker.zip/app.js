// BudgetPro Application JavaScript
class BudgetApp {
    constructor() {
        this.state = {
            monthlyIncome: 1344,
            budgetCategories: [
                { id: 1, name: "Gas", amount: 100, notes: "~600 mi/month commuting + buffer", color: "#FF6B6B" },
                { id: 2, name: "Car Insurance", amount: 0, notes: "Covered by family", color: "#4ECDC4" },
                { id: 3, name: "Groceries", amount: 0, notes: "Covered by family", color: "#45B7D1" },
                { id: 4, name: "UVU Tuition & Fees", amount: 480, notes: "$2,879.19/semester ÷ 6 months", color: "#96CEB4" },
                { id: 5, name: "Haircut (Valet Clippers)", amount: 30, notes: "Monthly grooming expense", color: "#FECA57" },
                { id: 6, name: "Dining Out", amount: 120, notes: "12 times/month × $10 average", color: "#FF9FF3" },
                { id: 7, name: "Utilities", amount: 0, notes: "Living with family", color: "#54A0FF" },
                { id: 8, name: "Rent", amount: 0, notes: "Living with family", color: "#5F27CD" },
                { id: 9, name: "Miscellaneous", amount: 90, notes: "Random stuff, social, tech, clothes", color: "#00D2D3" }
            ],
            savingsGoal: 500,
            isYearlyView: false,
            hideZeroCategories: false,
            editingCategoryId: null
        };
        
        this.charts = {
            expense: null,
            income: null
        };
        
        this.init();
    }

    init() {
        this.bindEvents();
        this.updateDashboard();
        this.renderCategories();
        this.initCharts();
    }

    bindEvents() {
        // Modal events
        document.getElementById('addCategoryBtn').addEventListener('click', () => this.openAddModal());
        document.getElementById('closeModal').addEventListener('click', () => this.closeAddModal());
        document.getElementById('modalBackdrop').addEventListener('click', () => this.closeAddModal());
        document.getElementById('cancelBtn').addEventListener('click', () => this.closeAddModal());
        document.getElementById('addCategoryForm').addEventListener('submit', (e) => this.handleAddCategory(e));

        // Edit modal events
        document.getElementById('closeEditModal').addEventListener('click', () => this.closeEditModal());
        document.getElementById('editModalBackdrop').addEventListener('click', () => this.closeEditModal());
        document.getElementById('cancelEditBtn').addEventListener('click', () => this.closeEditModal());
        document.getElementById('editCategoryForm').addEventListener('submit', (e) => this.handleEditCategory(e));
        document.getElementById('deleteCategoryBtn').addEventListener('click', () => this.handleDeleteCategory());

        // Toggle events
        document.getElementById('hideZeroCategories').addEventListener('change', (e) => {
            this.state.hideZeroCategories = e.target.checked;
            this.renderCategories();
        });

        document.getElementById('toggleView').addEventListener('click', () => this.toggleView());
        document.getElementById('exportBtn').addEventListener('click', () => this.exportData());

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAddModal();
                this.closeEditModal();
            }
        });
    }

    updateDashboard() {
        const totalBudget = this.getTotalBudget();
        const remaining = this.state.monthlyIncome - totalBudget;
        const budgetUtilization = (totalBudget / this.state.monthlyIncome) * 100;
        const savingsProgress = Math.min((remaining / this.state.savingsGoal) * 100, 100);
        
        // Update display values
        const multiplier = this.state.isYearlyView ? 12 : 1;
        document.getElementById('monthlyIncome').textContent = this.formatCurrency(this.state.monthlyIncome * multiplier);
        document.getElementById('totalBudget').textContent = this.formatCurrency(totalBudget * multiplier);
        document.getElementById('remainingAmount').textContent = this.formatCurrency(remaining * multiplier);
        document.getElementById('savingsGoal').textContent = this.formatCurrency(this.state.savingsGoal * multiplier);
        
        // Update category count
        const activeCategories = this.state.budgetCategories.filter(cat => cat.amount > 0).length;
        document.getElementById('budgetCount').textContent = `${activeCategories} active categories`;
        
        // Update remaining amount color
        const remainingElement = document.getElementById('remainingAmount');
        remainingElement.className = 'overview-card__amount';
        if (remaining >= this.state.savingsGoal) {
            remainingElement.classList.add('overview-card__amount--income');
        } else if (remaining >= 0) {
            remainingElement.classList.add('overview-card__amount--savings');
        } else {
            remainingElement.classList.add('overview-card__amount--expense');
        }
        
        // Update progress bars
        this.updateProgressBar('budgetProgress', budgetUtilization);
        this.updateProgressBar('savingsProgress', savingsProgress);
        
        // Update charts
        this.updateCharts();
    }

    updateProgressBar(id, percentage) {
        const progressBar = document.getElementById(id);
        const fill = progressBar.querySelector('.progress-bar__fill');
        fill.style.width = `${Math.min(percentage, 100)}%`;
        
        // Add visual feedback for over-budget
        if (percentage > 100) {
            fill.style.background = 'linear-gradient(90deg, #ff4757, #ff3838)';
        } else if (id === 'budgetProgress') {
            fill.style.background = 'linear-gradient(90deg, var(--color-primary), var(--color-teal-400))';
        } else {
            fill.style.background = 'linear-gradient(90deg, var(--color-success), var(--color-teal-300))';
        }
    }

    getTotalBudget() {
        return this.state.budgetCategories.reduce((total, category) => total + category.amount, 0);
    }

    renderCategories() {
        const grid = document.getElementById('categoriesGrid');
        grid.innerHTML = '';
        
        const categoriesToShow = this.state.hideZeroCategories 
            ? this.state.budgetCategories.filter(cat => cat.amount > 0)
            : this.state.budgetCategories;
        
        categoriesToShow.forEach((category, index) => {
            const categoryElement = this.createCategoryCard(category);
            categoryElement.style.animationDelay = `${index * 50}ms`;
            categoryElement.classList.add('slide-up');
            grid.appendChild(categoryElement);
        });
    }

    createCategoryCard(category) {
        const card = document.createElement('div');
        card.className = `card category-card ${category.amount === 0 ? 'category-card--zero' : ''}`;
        card.setAttribute('data-id', category.id);
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'button');
        card.setAttribute('aria-label', `Edit ${category.name} category`);
        
        const multiplier = this.state.isYearlyView ? 12 : 1;
        
        card.innerHTML = `
            <div class="card__body">
                <div class="category-card__header">
                    <div class="category-card__title">
                        <div class="category-card__color" style="background-color: ${category.color}"></div>
                        ${category.name}
                    </div>
                    <div class="category-card__amount">${this.formatCurrency(category.amount * multiplier)}</div>
                </div>
                ${category.notes ? `<div class="category-card__notes">${category.notes}</div>` : ''}
            </div>
        `;
        
        card.addEventListener('click', () => this.openEditModal(category.id));
        card.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.openEditModal(category.id);
            }
        });
        
        return card;
    }

    openAddModal() {
        document.getElementById('addCategoryModal').classList.remove('hidden');
        document.getElementById('categoryName').focus();
    }

    closeAddModal() {
        document.getElementById('addCategoryModal').classList.add('hidden');
        document.getElementById('addCategoryForm').reset();
    }

    openEditModal(categoryId) {
        const category = this.state.budgetCategories.find(cat => cat.id === categoryId);
        if (!category) return;
        
        this.state.editingCategoryId = categoryId;
        
        document.getElementById('editCategoryName').value = category.name;
        document.getElementById('editCategoryAmount').value = category.amount;
        document.getElementById('editCategoryNotes').value = category.notes || '';
        document.getElementById('editCategoryColor').value = category.color;
        
        document.getElementById('editCategoryModal').classList.remove('hidden');
        document.getElementById('editCategoryName').focus();
    }

    closeEditModal() {
        document.getElementById('editCategoryModal').classList.add('hidden');
        document.getElementById('editCategoryForm').reset();
        this.state.editingCategoryId = null;
    }

    handleAddCategory(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const newCategory = {
            id: Date.now(),
            name: document.getElementById('categoryName').value.trim(),
            amount: parseFloat(document.getElementById('categoryAmount').value) || 0,
            notes: document.getElementById('categoryNotes').value.trim(),
            color: document.getElementById('categoryColor').value
        };
        
        if (!newCategory.name) {
            alert('Please enter a category name');
            return;
        }
        
        this.state.budgetCategories.push(newCategory);
        this.closeAddModal();
        this.updateDashboard();
        this.renderCategories();
        
        // Show success feedback
        this.showNotification('Category added successfully!', 'success');
    }

    handleEditCategory(e) {
        e.preventDefault();
        
        const categoryIndex = this.state.budgetCategories.findIndex(cat => cat.id === this.state.editingCategoryId);
        if (categoryIndex === -1) return;
        
        const updatedCategory = {
            ...this.state.budgetCategories[categoryIndex],
            name: document.getElementById('editCategoryName').value.trim(),
            amount: parseFloat(document.getElementById('editCategoryAmount').value) || 0,
            notes: document.getElementById('editCategoryNotes').value.trim(),
            color: document.getElementById('editCategoryColor').value
        };
        
        if (!updatedCategory.name) {
            alert('Please enter a category name');
            return;
        }
        
        this.state.budgetCategories[categoryIndex] = updatedCategory;
        this.closeEditModal();
        this.updateDashboard();
        this.renderCategories();
        
        // Show success feedback
        this.showNotification('Category updated successfully!', 'success');
    }

    handleDeleteCategory() {
        if (!confirm('Are you sure you want to delete this category?')) return;
        
        this.state.budgetCategories = this.state.budgetCategories.filter(cat => cat.id !== this.state.editingCategoryId);
        this.closeEditModal();
        this.updateDashboard();
        this.renderCategories();
        
        // Show success feedback
        this.showNotification('Category deleted successfully!', 'success');
    }

    toggleView() {
        this.state.isYearlyView = !this.state.isYearlyView;
        const button = document.getElementById('toggleView');
        button.textContent = this.state.isYearlyView ? 'Yearly View' : 'Monthly View';
        
        this.updateDashboard();
        this.renderCategories();
    }

    initCharts() {
        this.initExpenseChart();
        this.initIncomeChart();
    }

    initExpenseChart() {
        const ctx = document.getElementById('expenseChart').getContext('2d');
        const categories = this.state.budgetCategories.filter(cat => cat.amount > 0);
        
        this.charts.expense = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: categories.map(cat => cat.name),
                datasets: [{
                    data: categories.map(cat => cat.amount),
                    backgroundColor: categories.map(cat => cat.color),
                    borderWidth: 0,
                    hoverOffset: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 12
                            }
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => {
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((context.parsed / total) * 100).toFixed(1);
                                return `${context.label}: ${this.formatCurrency(context.parsed)} (${percentage}%)`;
                            }
                        }
                    }
                },
                cutout: '60%'
            }
        });
    }

    initIncomeChart() {
        const ctx = document.getElementById('incomeChart').getContext('2d');
        const totalExpenses = this.getTotalBudget();
        const remaining = this.state.monthlyIncome - totalExpenses;
        
        this.charts.income = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Income', 'Expenses', 'Remaining'],
                datasets: [{
                    data: [this.state.monthlyIncome, totalExpenses, Math.max(0, remaining)],
                    backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C'],
                    borderRadius: 8,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: (context) => `${context.label}: ${this.formatCurrency(context.parsed.y)}`
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: (value) => this.formatCurrency(value)
                        }
                    }
                }
            }
        });
    }

    updateCharts() {
        if (this.charts.expense) {
            const categories = this.state.budgetCategories.filter(cat => cat.amount > 0);
            const multiplier = this.state.isYearlyView ? 12 : 1;
            
            this.charts.expense.data.labels = categories.map(cat => cat.name);
            this.charts.expense.data.datasets[0].data = categories.map(cat => cat.amount * multiplier);
            this.charts.expense.data.datasets[0].backgroundColor = categories.map(cat => cat.color);
            this.charts.expense.update();
        }
        
        if (this.charts.income) {
            const totalExpenses = this.getTotalBudget();
            const remaining = this.state.monthlyIncome - totalExpenses;
            const multiplier = this.state.isYearlyView ? 12 : 1;
            
            this.charts.income.data.datasets[0].data = [
                this.state.monthlyIncome * multiplier,
                totalExpenses * multiplier,
                Math.max(0, remaining * multiplier)
            ];
            this.charts.income.update();
        }
    }

    exportData() {
        const totalBudget = this.getTotalBudget();
        const remaining = this.state.monthlyIncome - totalBudget;
        const multiplier = this.state.isYearlyView ? 12 : 1;
        const viewType = this.state.isYearlyView ? 'Yearly' : 'Monthly';
        
        let exportText = `BudgetPro ${viewType} Budget Report\n`;
        exportText += `Generated on: ${new Date().toLocaleDateString()}\n\n`;
        exportText += `${viewType} Income: ${this.formatCurrency(this.state.monthlyIncome * multiplier)}\n`;
        exportText += `Total Budget: ${this.formatCurrency(totalBudget * multiplier)}\n`;
        exportText += `Remaining: ${this.formatCurrency(remaining * multiplier)}\n`;
        exportText += `Savings Goal: ${this.formatCurrency(this.state.savingsGoal * multiplier)}\n\n`;
        
        exportText += 'Budget Categories:\n';
        exportText += '-'.repeat(50) + '\n';
        
        this.state.budgetCategories.forEach(category => {
            exportText += `${category.name}: ${this.formatCurrency(category.amount * multiplier)}`;
            if (category.notes) {
                exportText += ` (${category.notes})`;
            }
            exportText += '\n';
        });
        
        // Create and download file
        const blob = new Blob([exportText], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `budget-report-${new Date().toISOString().split('T')[0]}.txt`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        this.showNotification('Budget report exported successfully!', 'success');
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification--${type}`;
        notification.textContent = message;
        
        // Add to DOM
        document.body.appendChild(notification);
        
        // Animate in
        setTimeout(() => notification.classList.add('notification--visible'), 10);
        
        // Remove after delay
        setTimeout(() => {
            notification.classList.remove('notification--visible');
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new BudgetApp();
});

// Add notification styles dynamically
const notificationStyles = `
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 12px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    font-size: 14px;
    z-index: 2000;
    transform: translateX(100%);
    opacity: 0;
    transition: all 0.3s ease;
    max-width: 300px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

.notification--visible {
    transform: translateX(0);
    opacity: 1;
}

.notification--success {
    background-color: var(--color-success);
}

.notification--error {
    background-color: var(--color-error);
}

.notification--info {
    background-color: var(--color-info);
}
`;

const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);